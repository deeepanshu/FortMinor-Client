//tether is a requirement for bootstrap v4
import Tether from 'tether'

window.Tether = Tether
