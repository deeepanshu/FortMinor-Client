//popper.js is a requirement for bootstrap v4
import Popper  from 'popper.js'

window.Popper = Popper
