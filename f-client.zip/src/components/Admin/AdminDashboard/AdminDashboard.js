import React from "react";

const AdminDashboard = props =>(
    <div>
        Admin Dashboard
    </div>
);
export default  AdminDashboard;