import React from 'react';
//import {NavLink} from "react-router-dom";

const UserQueries = props =>(
    <div>
        UserQueries
    </div>
)
export default UserQueries;