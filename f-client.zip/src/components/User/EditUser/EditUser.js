import React from 'react';
//import {NavLink} from "react-router-dom";

const EditUser = props =>(
    <div>
        EditUser
    </div>
)
export default EditUser;